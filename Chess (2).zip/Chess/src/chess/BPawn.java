/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess;

/**
 *
 * @author aghaj
 */
public class BPawn  extends Move{
        private  int i ;
    private  int j ;
    boolean movable;
    boolean isKing;
    boolean isUnpasan;
    
    private void Promotion(int i,int j,Move pawn){
                if(j==0){
                    pawn = new Queen();
            board[i][j] = pawn;
                }
    }
    protected boolean isMovable(int i, int j,Move pawn){
       
        boolean isempty = false;
        for(int d = j; d < pawn.getYPos();d++){
            
            if(!isEmpty(i,d)){

                isempty = false;
                break;
               
            }
            isempty = true;
        }
        return isempty;
    }

    private void unpasan(){
        
    }
     @Override
    public void move(int i, int j, boolean color, Move pawn){
        // Moshkelesh az isMovable() hast
        
        if(!globTurn &&i ==  this.i &&( j == 5 || j ==4)&& isMovable(i,j,pawn)&&   isEmpty(i,j) && notPinned(this.i,this.j,i,j)){

        marker(i,j,pawn);
          moveAllowed = true ;
    }
        else if(!globTurn &&i== getXPos()&& j == getYPos()-1 && j <7 && j >=0&&   isEmpty(i,j) && notPinned(this.i,this.j,i,j) && isMovable(i,j,pawn)){
        marker(i,j,pawn);
        if( j == 0){
            Promotion(i,j,pawn);
        }
        
          moveAllowed = true ;
          // pic shoud change to queen
    }
        else if(!globTurn &&(getXPos() +1 == i || i == getXPos()-1) && (getYPos() - 1)==j && isOpp(i,j) && notPinned(this.i,this.j,i,j) ){
            hit(i,j,this.i,this.j,pawn);
                    if( j == 0){
            Promotion(i,j,pawn);
             
              //pic should change to queen             
        }
                     moveAllowed = true ;
                     captured = true;
        }

        else 
            wrongMove();
    }

    @Override
    protected int getXPos() {
        
        return i;
    }

    @Override
    protected int getYPos() {
        return j;
    }

    @Override
    protected void setXPos(int i) {
        
       this.i =i;
    }

    @Override
    protected void setYPos(int j) {
        this.j = j;
    }

}
